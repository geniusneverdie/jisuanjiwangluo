#pragma once
#include <winsock2.h>
#include<WS2tcpip.h>
#include <iostream>
#include <fstream>
#include <string>
#include<iomanip>
#include <ctime>
#include<stdlib.h>
#include <windows.h>
#include <mutex>
#include "UDP.h"
#pragma comment(lib, "Ws2_32.lib")

#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define MAX_TIME  0.1*CLOCKS_PER_SEC 
#define WindowLen 32
#define TWICE_GAP 64
using namespace std;

const double LOSS_RATE = 0.05;// �����ʣ�0.1 ��ʾ10%�Ķ����ʣ�

void SimulateDelay() {
    double i = rand() / RAND_MAX;
    if (i < 0)
        Sleep(MAX_TIME);
}

bool SimulateDrop() {

    double i = rand() / double(RAND_MAX);
    return i < LOSS_RATE;
}
class Sender {
private:

    SOCKET s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    sockaddr_in* dst_addr = new sockaddr_in();
    sockaddr_in* src_addr = new sockaddr_in();

    string fileName = "1.txt";
    streamsize fileSize = 0;

    volatile bool connected = false;
    int bytes;

    // ͣ��
    Udp* package;
    char* SendBuffer = new char[PacketSize];
    char* FileBuffer;

    //GBN
    volatile int Window = WindowLen;
    volatile int base = 0;
    volatile int nextseq = 0;
    volatile bool Re = 0;
    volatile clock_t timer;
    pQueue watiBuffer = pQueue(Window);


    //�����߳̿���
    volatile bool send_runner_keep = true;

public:

    Sender();
    int _send(Udp* pack, int payload_size);
    int _send(int size);
    int get_connection(int type);
    void print_info() { print_udp(*package); }

    void GetFile(string name) {
        this->fileName = name;
        this->fileSize = ReadFile(name, this->FileBuffer);
    };
    void init() {
        memset(this->SendBuffer, 0, PacketSize);
        send_runner_keep = true;
        connected = false;

        bytes = 0;
    }
    friend DWORD WINAPI SConnectHandler(LPVOID param);
    friend DWORD WINAPI SendHandler(LPVOID param);
    friend DWORD WINAPI GBNReciHandle(LPVOID param);
    friend DWORD WINAPI GBNSendHandle(LPVOID param);
    friend DWORD WINAPI SRReciHandle(LPVOID param);
    friend DWORD WINAPI SRSendHandle(LPVOID param);
    friend DWORD WINAPI SRReSendHandle(LPVOID param);
    ~Sender();
};
Sender::Sender() {
    //srand(static_cast<unsigned int>(time(0)));
    //Bind 8998 
    this->src_addr->sin_family = AF_INET;
    this->src_addr->sin_port = htons(8998);
    inet_pton(AF_INET, ReciIp, &(src_addr->sin_addr));
    int iResult = bind(s, (struct sockaddr*)this->src_addr, sizeof(*src_addr));
    //���Խ��׽��� s ����ǰ��ʼ���ĵ�ַ�ṹ����һ�������ʧ�ܣ������������Ϣ
    if (iResult != 0)
        cout << "Bind failed: " << WSAGetLastError() << endl;

    else
        cout << "�����ѽ���\n" << "�˿�: " << ntohs(this->src_addr->sin_port) << endl;

    //������̬
    unsigned long mode = 1;//���׽�������Ϊ������ģʽ��ͨ��ioctlsocket����ʵ�֡�����ζ���׽��ֵĲ����������������ִ�У����ǻ���������
    ioctlsocket(this->s, FIONBIO, &mode);
    this->FileBuffer = new char[BufferSize];

    this->package = new Udp();
    this->bytes = 0;

    this->timer = clock();
}
Sender::~Sender() {
    closesocket(s);
    send_runner_keep = false;
}

int Sender::_send(int size) {
    return this->_send(this->package, size);
}
int Sender::_send(Udp* pack, int size) {
    char* buffer = new char[size + HeadSize];
    memcpy(buffer, pack, size + HeadSize);

    int rst_byte = -1;
    if (!SimulateDrop()) {
        SimulateDelay();

        rst_byte = sendto(this->s, buffer, size + HeadSize, 0, (sockaddr*)this->dst_addr, sizeof(*this->dst_addr));

        char error_message[100];
        if (rst_byte == SOCKET_ERROR) {
            int error_code = WSAGetLastError();
            cerr << "���ʹ���: " << error_code << endl;
            return rst_byte;
        }
    }
    else
        cout << "------------------------------ ���� ------------------------------- " << endl;

    print_udp(*pack, 1);
    this->bytes += size + HeadSize;

    delete[] buffer;
    return rst_byte;

}

DWORD WINAPI SRReciHandle(LPVOID param) {
    srand((unsigned)time(NULL));
    Sender* s = (Sender*)param;
    char* ReciBuffer = new char[PacketSize];
    clock_t sec_st = clock();
    socklen_t dst_addr_len = sizeof(*s->dst_addr);

    while (true) {

        while (recvfrom(s->s, ReciBuffer, PacketSize, 0, (struct sockaddr*)s->dst_addr, &dst_addr_len) <= 0)
        {
            if (clock() - s->timer > MAX_TIME)
                //�ط�
            {
                s->timer = clock();
                s->Re = 1;
                //CreateThread(NULL, 0, SRReSendHandle, (LPVOID)s, 0, NULL);
            }
        }
        Udp* dst_package = (Udp*)ReciBuffer;
        if (
            (dst_package->cmp_cheksum())
            && (dst_package->header.get_Ack())
            )//���У���ƥ�������ݰ��� ACK ��־Ϊ��
        {
            int rst = s->watiBuffer.SRpop(*dst_package);
            //���� s->watiBuffer.SRpop(*dst_package) �������Դӵȴ��������е������ݰ�
            switch (rst) {
            case -1:
                //ACK�ڴ��ڷ�Χ��
                cout << endl;
                print_udp(*dst_package, 3);
                break;
            case 0:
                //ACK����ȷ�ϣ�����һ����ûȷ��
                cout << endl;
                print_udp(*dst_package, 2);
                break;
            default:
                s->base += rst;
                cout << " [window] --> " << rst << " base: " << s->base << endl;
                s->timer = clock();
                print_udp(*dst_package, 2);
                break;
            }
            //˵�� ACK ����ȷ�ϣ��ƶ����ڵĻ���� s->base�����¼�ʱ��
            if (dst_package->header.get_Fin()) {//�رշ��ͽ���
                s->send_runner_keep = false;
                break;
            }//������յ������ݰ��� FIN ��־Ϊ�棬��ʾ���ͽ���Ӧ�ùر�
        }

    }
    cout << "��ȡ����" << endl;
    return 0;
}
DWORD WINAPI SRSendHandle(LPVOID param) {
    srand((unsigned)time(NULL));
    Sender* s = (Sender*)param;
    char* iter = s->FileBuffer;
    streamsize fileSize = s->fileSize;
    char* end = iter + fileSize;

    string name_size = s->fileName + ":" + to_string(s->fileSize);

    //status ST  ACK FIN  ack seq
    bool ST = 1;
    bool END = 0;
    bool ACK = 0;
    bool FIN = 0;
    int ack = -1;
    int seq = 0;
    int payloadSize = PayloadSize;


    while (s->send_runner_keep) {


        int N = s->Window;

        if (FIN || s->Re) {
            //������յ� FIN ��־���� s->Re Ϊ�棬��ʾ��Ҫ�����ش����ߴ��������е����ݰ�
            //Recive�߳̽�s->Re��λ���Դ��ڶ����еĽ��з��͡�
            vector<Udp*>tmp = s->watiBuffer.data;
            vector<bool>waitAck = s->watiBuffer.waitAck;
            int i = 0;
            for (Udp* p : tmp) {
                p->header.set_r(1);
                if (!waitAck[i++])
                    s->_send(p, p->header.data_size);
                Sleep(TWICE_GAP);
            }
            //Ҫ�ش���������ȴ��������е����ݰ������� R ��־��λ��������δȷ�ϵ����ݰ���Ȼ�� s->Re ��λΪ 0 ������ѭ��
            //s->watiBuffer.SRpop(0);
            s->Re = 0;
            continue;
        }
        //���淢�ͣ��Դ��������ݽ��з���
        while (s->nextseq < s->base + N) {
            //�����������ݰ���ѭ�����ʹ����ڵ����ݰ�
            Udp* package = new Udp(ST, ACK, FIN, seq, ack);
            //����״̬λ��package��flagλ������λ
            if (FIN)
            {
                s->watiBuffer.push(package);
                s->_send(package, 0);
                // s->send_runner_keep=0;
                break;
            }

            else if (ST)
                package->packet_data(name_size.c_str(), sizeof(name_size));

            else {
                package->packet_data(iter, payloadSize);
                iter += PayloadSize;
            }

            s->watiBuffer.push(package);
            s->_send(package, payloadSize);

            //�����ʱ��seq++ע�ⲻ�ܻ�λ
            if (s->base == s->nextseq)
                s->timer = clock();
            //����ţ�base��������һ����ţ�nextseq������ʾ�����е����ݰ����ѷ���
            seq++;
            s->nextseq++;

            //״̬�ı�
            if (ST && !FIN)
                ST = 0;


            if (!ST && (iter + PayloadSize) > end) {
                payloadSize = end - iter;
                FIN = 1;
                //���ǳ�ʼ״̬���Ѿ������ļ�������ĩβ��iter + PayloadSize ������ end�������� FIN ��־Ϊ��
            }
            Sleep(TWICE_GAP);
        }
    }
    cout << "SR ���ͽ���" << endl;
    return 0;
}
DWORD WINAPI SRReSendHandle(LPVOID param) {
    Sender* s = (Sender*)param;
    if (s->Re) {
        //��Ҫ�����ش�
        //Recive�߳̽�s->Re��λ���Դ��ڶ����еĽ��з��͡�
        vector<Udp*>tmp = s->watiBuffer.data;
        vector<bool>waitAck = s->watiBuffer.waitAck;
        int i = 0;
        for (Udp* p : tmp) {
            p->header.set_r(1);
            if (!waitAck[i++])//���ݰ�δ��ȷ�ϣ�!waitAck[i++]������ R ��־��λ�������� _send �����������ݰ�
                s->_send(p, p->header.data_size);
            Sleep(TWICE_GAP);//ͨ�� Sleep �����ȴ�һ��ʱ�䣬��ģ�⴫���ӳ�
        }
        s->Re = 0;
    }
    return 1;
}

DWORD WINAPI GBNReciHandle(LPVOID param) {

    srand((unsigned)time(NULL));
    Sender* s = (Sender*)param;
    char* ReciBuffer = new char[PacketSize];
    clock_t sec_st = clock();
    socklen_t dst_addr_len = sizeof(*s->dst_addr);

    while (true) {
        while (recvfrom(s->s, ReciBuffer, PacketSize, 0, (struct sockaddr*)s->dst_addr, &dst_addr_len) <= 0)
        {
            if (clock() - s->timer > MAX_TIME)
                //�ط�
            {
                s->timer = clock();
                s->Re = 1;
            }
        }
        Udp* dst_package = (Udp*)ReciBuffer;
        //int dst_ack = dst_package->header.ack;

        if (
            (dst_package->cmp_cheksum())
            && (dst_package->header.get_Ack())
            )
        {

            int rst = s->watiBuffer.GBNpop(*dst_package);
            switch (rst) {
            case -1:
                //�ظ�����ACK
                print_udp(*dst_package, 3);
                break;
            default:
                //���ڷ��Ͷ�ACK��ʧ�����ӳ�
                s->base += rst;
                cout << "[window] -- > " << rst << " base: " << s->base << endl;
                s->timer = clock();
                print_udp(*dst_package, 2);
                break;
            }
            if (dst_package->header.get_Fin()) {//�رշ��ͽ���
                s->send_runner_keep = false;
                break;
            }
        }

    }
    cout << "��ȡ����" << endl;
    return 0;
}
DWORD WINAPI GBNSendHandle(LPVOID param) {
    srand((unsigned)time(NULL));
    Sender* s = (Sender*)param;
    char* iter = s->FileBuffer;
    streamsize fileSize = s->fileSize;
    char* end = iter + fileSize;

    string name_size = s->fileName + ":" + to_string(s->fileSize);

    //status ST  ACK FIN  ack seq
    bool ST = 1;
    bool END = 0;
    bool ACK = 0;
    bool FIN = 0;
    int ack = -1;
    int seq = 0;
    int payloadSize = PayloadSize;


    while (s->send_runner_keep) {

        int N = s->Window;
        if (FIN || s->Re) {
            vector<Udp*>tmp = s->watiBuffer.data;
            for (Udp* p : tmp) {
                p->header.set_r(1);
                s->_send(p, p->header.data_size);
                Sleep(TWICE_GAP);
            }
            //s->watiBuffer.SRpop(0);
            s->Re = 0;
            continue;
        }
        while (s->nextseq < s->base + N) {

            //����
            Udp* package = new Udp(ST, ACK, FIN, seq, ack);
            if (FIN)
            {
                s->watiBuffer.push(package);
                s->_send(package, 0);
                // s->send_runner_keep=0;
                break;
            }

            else if (ST)
                package->packet_data(name_size.c_str(), sizeof(name_size));

            else {
                package->packet_data(iter, payloadSize);
                iter += PayloadSize;
            }
            s->watiBuffer.push(package);
            s->_send(package, payloadSize);
            if (s->base == s->nextseq)
                s->timer = clock();

            seq++;
            s->nextseq++;
            //״̬�ı�
            if (ST && !FIN)
                ST = 0;


            if (!ST && (iter + PayloadSize) > end) {
                payloadSize = end - iter;
                FIN = 1;

            }
            Sleep(TWICE_GAP);
        }
    }
    cout << "GBN ���ͽ��̽���" << endl;
    return 0;
}


DWORD WINAPI SendHandler(LPVOID param) {
    srand((unsigned)time(NULL));
    char* ReciBuffer = new char[PacketSize];
    Sender* sender = (Sender*)param;


    string name_size = sender->fileName + ":" + to_string(sender->fileSize);

    /* �����ļ� ���ڹ̶�payloadSize*/
    char* iter = sender->FileBuffer;
    streamsize indx = 0;


    streamsize fileSize = sender->fileSize;
    int payload_size = sizeof(name_size);


    int seq = 0;
    bool status = 0;
    bool st = 1;
    bool fin = 0;

    clock_t send_st = clock();
    while (sender->send_runner_keep && !fin) {
        //����seq״̬0/1�İ� 
        if (st)
        {   sender->package->set_status(status);
            sender->package->set_flag(st, fin);
            sender->package->packet_data(name_size.c_str(), payload_size);

            sender->_send(payload_size);

            //cout.write(sender->package.payload, sizeof(name_size));
            //cout << endl;
            st = false;
        }


        /*����ack status!=  ��ʱ�ش� */
        clock_t sec_st = clock();
        socklen_t dst_addr_len = sizeof(*sender->dst_addr);
        Sleep(TWICE_GAP);
        while (true) {
            while (recvfrom(sender->s, ReciBuffer, PacketSize, 0, (struct sockaddr*)sender->dst_addr, &dst_addr_len) <= 0)
            {
                if (clock() - sec_st > MAX_TIME) {
                    cout << "\n-------------------- ��ʱ  -----------------\n" << "���·��ͣ�����status " << status << " ����seq " << seq << endl;
                    sender->_send(payload_size);
                    sec_st = clock();
                }
            }

            Udp* dst_package = (Udp*)ReciBuffer;
            if (
                (dst_package->cmp_cheksum())
                && (dst_package->header.get_status() == status)
                && (dst_package->header.get_Ack())
                )
            {         //ͨ��У��͡���Ӧ״̬
                cout << "----- ���-----\n";
                if (dst_package->header.get_end()) {
                    fin = 1;
                    sender->send_runner_keep = false;
                    break;
                }
                if (!dst_package->header.get_st())
                    indx += PayloadSize;

                //״̬ת��
                status = !status;
                sender->package->header.set_Status(status);


                //����´η���
                sender->package->header.seq = ++seq;
                sender->package->header.ack = dst_package->header.seq + 1;

                if (indx + PayloadSize > fileSize) {

                    payload_size = fileSize - indx;
                    sender->package->set_flag(0, 0, status, 1, 0, 1);

                }

                else {
                    payload_size = PayloadSize;
                    sender->package->set_flag(0, 0, status, 1, 0, 0);
                }

                sender->package->header.data_size = payload_size;
                sender->package->packet_data(iter + indx, payload_size);
                sender->_send(payload_size);
                break;
            }
            else {
                cout << "----- ��� -----\n ";
                sender->_send(payload_size);
                cout << "���·��ͣ�����status " << status << " ����seq " << seq << endl;
            }
        }
    }
    cout << "���ͽ���\n";
    return 0;
}
DWORD WINAPI SConnectHandler(LPVOID param) {
    srand((unsigned)time(NULL));
    char* ReciBuffer = new char[PacketSize];


    Sender* sender = (Sender*)param;
    socklen_t dst_addr_len = sizeof(*sender->dst_addr);

    bool SYN = 1;
    bool ACK = 0;
    bool RE = 0;
    bool succed = 0;

    clock_t sec_st = clock();

    while (!succed) {

        sender->package->set_flag(SYN, 0, ACK);
        if (RE)
            sender->package->header.set_r(1);
        RE = 0;
        sender->package->set_cheksum();
        sender->_send(0);

        while (recvfrom(sender->s, ReciBuffer, PacketSize, 0, (struct sockaddr*)sender->dst_addr, &dst_addr_len) <= 0) {

            if (clock() - sec_st > 5 * MAX_TIME) {
                cout << "\n--------------------��ʱ  -----------------\n";
                sender->_send(0);
                sec_st = clock();
            }
        }

        Udp* dst_package = (Udp*)ReciBuffer;
        print_udp(*dst_package, 2);
        int dSYN = dst_package->header.get_Syn();
        int dACK = dst_package->header.get_Ack();
        if (
            (dst_package->cmp_cheksum())
            && (dst_package->header.get_Ack())
            )//У��͡�ACK
        {
            
            if (SYN && !ACK) {
                if (dSYN && dACK)
                {
                    SYN = 0;ACK = 1;
                    //  cout << "�ڶ��λ��ֳɹ�"<<endl;

                    succed = true;
                    cout << "Send Thread Ready" << endl;
                }
                else {
                    //  cout << "�ڶ��λ���ʧ��" << endl;
                    continue;
                }


            }
            else
            {   //���»�1״̬
                SYN = 1;ACK = 0;RE = 1;
            }

        }
    }
    sender->package->set_flag(0, 0, ACK);
    sender->package->set_cheksum();
    sender->_send(0);
    sender->connected = 1;
    delete[] ReciBuffer;
    return 1;
}

int Sender::get_connection(int type) {
    this->dst_addr->sin_family = AF_INET;
    this->dst_addr->sin_port = htons(8999);
    inet_pton(AF_INET, ReciIp, &(this->dst_addr->sin_addr));
   
    cout << "Dst Prot: " << ntohs(this->dst_addr->sin_port) << endl;
    
    /*��������*/

    cout << "��������\n\n" << endl;
    CreateThread(NULL, 0, SConnectHandler, (LPVOID)this, 0, NULL);
    while (!this->connected)
        Sleep(100);

    clock_t send_st;
    switch (type)
    {
    case 1:
        cout << "\n������ " << endl;
        send_st = clock();
        CreateThread(NULL, 0, SendHandler, (LPVOID)this, 0, NULL);

        break;

    case 2:
        cout << "\nGBN ���� " << endl;
        CreateThread(NULL, 0, GBNReciHandle, (LPVOID)this, 0, NULL);
        send_st = clock();
        CreateThread(NULL, 0, GBNSendHandle, (LPVOID)this, 0, NULL);
        break;
    default:
        cout << "\nSR ���� " << endl;
        CreateThread(NULL, 0, SRReciHandle, (LPVOID)this, 0, NULL);
        send_st = clock();
        CreateThread(NULL, 0, SRSendHandle, (LPVOID)this, 0, NULL);
        break;
    }
    while (this->send_runner_keep)
        Sleep(100);

    Sleep(100);
    SetConsoleTextAttribute(hConsole, BACKGROUND_BLUE | BACKGROUND_GREEN);
    cout << "\n[SYS STATUS] " << endl;
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

    cout << "[TOTAL BYTES] " << this->bytes << " bs\n"
        << "[DURATION] " << double(clock() - send_st) / CLOCKS_PER_SEC << " s"
        << endl;
    if ((clock() - send_st) / CLOCKS_PER_SEC)
        cout << "[SPEED RATE] " << double(this->bytes / ((clock() - send_st) / CLOCKS_PER_SEC)) << " Bps\n";
    return 1;
}