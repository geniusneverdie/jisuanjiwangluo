﻿#include <string>
#include <time.h>

//#include "Reciver.h"
#include "client.h"
#pragma comment(lib, "Ws2_32.lib")

#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define GBN 2
#define SR 3
using namespace std;




int main() {
    cout << "----- SR  测试 ----- \n";
    cout << "默认丢包率为：5%, 延迟：30ms 发送端、接收端窗口大小 16" << endl;
    //string filename = "helloworld.txt";
    string filename;//= "2.jpg";
    string cin_buffer;

    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != NO_ERROR)
        cout << "WSA启动失败" << iResult << endl;

    Sender sender = Sender();
    //sender.GetFile(filename);
    //sender.get_connection(2);


    while (true) {
        cout << "输入 filename: ";
        cin >> filename;
        sender.GetFile(filename);
        sender.init();
        sender.get_connection(SR);

        cout << "  press q to exit\n";
        cin >> cin_buffer;
        if (cin_buffer == "q")
            break;
    }

}