﻿#include<iostream>
#include<winsock2.h>
#pragma comment(lib,"ws2_32.lib") 
using namespace std;
int client_start() {
    WORD sockVersion = MAKEWORD(2, 2);
    WSADATA wsaData;
    if (WSAStartup(sockVersion, &wsaData) != 0)
    {
        return 0;
    }//初始化Winsock库，并检查初始化是否成功。如果初始化失败，函数会返回0。
    while (true) {//进入一个无限循环来与服务器进行连接和通信。
        SOCKET client_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (client_sock == INVALID_SOCKET) {
            printf("INVALID scoket");
            return 0;
        }//创建一个套接字（socket）来与服务器建立连接。并检查是否有效，无效则打印错误消息并返回0
        sockaddr_in sock_addr;//配置服务器信息
        sock_addr.sin_family = AF_INET;
        sock_addr.sin_port = htons(30000);
        sock_addr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
        if (connect(client_sock, (sockaddr*)&sock_addr, sizeof(sock_addr)) == SOCKET_ERROR) {
            printf("连接Server失败");
            closesocket(client_sock);
            return 0;
        }//尝试通过connect函数与服务器进行连接，如果连接失败则打印错误消息，关闭套接字并返回0。
        char* sendBuffer = new char[255];//存储待发送的消息。
        string tpstring = "Hi,genius1";

        for (int i = 0; i < tpstring.length();i++) {
            sendBuffer[i] = tpstring[i];
        }//将要发送的字符串tpstring复制到缓冲区中。
        sendBuffer[tpstring.length()] = 0x00;
        send(client_sock, sendBuffer, tpstring.length(), 0);
        char* reciBuffer = new char[255];//接收从服务器接收到的消息
        int ret = recv(client_sock, reciBuffer, 255, 0);//使用recv函数从服务器接收数据
        if (ret > 0) {
            reciBuffer[ret] = 0x00;
            printf("接受从Server: \n");
            printf(reciBuffer);
        }
        closesocket(client_sock);
    }
    WSACleanup();
    return 0;
}